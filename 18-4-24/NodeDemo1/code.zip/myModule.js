//Author: Rhett Bulkley
export function sayHello() {
  return "Hello!";
}

export default sayHello