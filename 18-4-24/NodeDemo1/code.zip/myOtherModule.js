// Author: Rhett Bulkley
export function sayHello (name) {
  return `Hello ${name}`
}
export function addTwoNumbers (num1, num2) {
  return num1 + num2
}